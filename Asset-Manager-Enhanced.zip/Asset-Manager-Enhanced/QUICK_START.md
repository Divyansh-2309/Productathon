# Quick Start Guide

Get your Asset Manager up and running in 5 minutes!

## Prerequisites Check
```bash
node --version  # Should be v20 or higher
npm --version   # Should be v9 or higher
psql --version  # PostgreSQL should be installed
```

## 1. Install Dependencies
```bash
npm install
```

## 2. Setup Database

### Create PostgreSQL Database
```bash
# Login to PostgreSQL
psql -U postgres

# Create database
CREATE DATABASE asset_manager;

# Exit
\q
```

### Configure Environment
Create `.env` file in the root directory:
```env
DATABASE_URL=postgresql://postgres:your_password@localhost:5432/asset_manager
SESSION_SECRET=generate-a-random-string-here
NODE_ENV=development
```

### Initialize Database Schema
```bash
npm run db:push
```

## 3. Start Development Server
```bash
npm run dev
```

Visit `http://localhost:5000` in your browser!

## 4. Create Your First Account

1. Click "Sign up" on the landing page
2. Fill in your details:
   - Name: Your Name
   - Email: admin@example.com
   - Role: Admin (for full access)
   - Password: (minimum 6 characters)
3. Click "Create Account"
4. Sign in with your credentials

## 5. Explore Features

### As Admin, you can:
- ✅ Create and manage tasks
- ✅ Add contractors and officers
- ✅ Send messages to team members
- ✅ View detailed reports
- ✅ Customize your theme
- ✅ Manage all system data

### Test the Features:

**Create a Contractor:**
1. Go to Contractors page
2. Click "Add Contractor"
3. Fill in the profile details
4. Add skills and certifications

**Create a Task:**
1. Navigate to Tasks page
2. Click "Create Task"
3. Assign to a contractor
4. Set priority and progress

**Send a Message:**
1. Go to Messages page
2. Click "Compose"
3. Select a recipient
4. Write and send your message

**Change Theme:**
1. Open Settings page
2. Choose from 15 available themes
3. Toggle dark mode if desired

**View Reports:**
1. Navigate to Reports page
2. Select report type
3. View interactive charts and analytics

## Troubleshooting

### Port Already in Use
If port 5000 is busy, edit `server/index.ts`:
```typescript
const PORT = process.env.PORT || 3000; // Change 5000 to 3000
```

### Database Connection Error
- Verify PostgreSQL is running: `pg_ctl status`
- Check your DATABASE_URL in `.env`
- Ensure the database exists

### Cannot Find Module Errors
```bash
rm -rf node_modules package-lock.json
npm install
```

## Production Build

```bash
# Build the application
npm run build

# Start production server
npm start
```

## Default Test Accounts

After setup, you can create these test accounts:

| Role | Email | Purpose |
|------|-------|---------|
| Admin | admin@test.com | Full system access |
| Officer | officer@test.com | Lead & task management |
| Contractor | contractor@test.com | Profile & task updates |
| Customer | customer@test.com | View projects |

## Next Steps

1. Customize the theme in Settings
2. Add your team members
3. Create your first project
4. Set up tasks and assignments
5. Start collaborating!

## Need Help?

- 📖 Read the full [README.md](README.md)
- 📋 Check [IMPLEMENTATION_GUIDE.md](IMPLEMENTATION_GUIDE.md)
- 🐛 Found a bug? Create an issue

Happy managing! 🚀
