
import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

// Users table for authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull(), // "admin", "officer", "contractor", "customer"
  theme: text("theme").default("default"),
  createdAt: timestamp("created_at").defaultNow(),
  lastLogin: timestamp("last_login"),
});

export const officers = pgTable("officers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  region: text("region").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
});

export const contractors = pgTable("contractors", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  company: text("company").notNull(),
  role: text("role").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  bio: text("bio"),
  skills: jsonb("skills").$type<string[]>(),
  certifications: jsonb("certifications").$type<string[]>(),
  hourlyRate: integer("hourly_rate"),
  availability: text("availability").default("Available"),
  rating: integer("rating").default(5),
  completedProjects: integer("completed_projects").default(0),
  profileImage: text("profile_image"),
});

// Customers table
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  company: text("company"),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  address: text("address"),
});


export const leads = pgTable("leads", {
  id: serial("id").primaryKey(),
  companyName: text("company_name").notNull(),
  location: text("location"),
  industry: text("industry"),
  signal: text("signal"), // e.g. "Tender", "News"
  recommendedProducts: jsonb("recommended_products").$type<string[]>(), // Array of strings
  confidence: integer("confidence").default(0),
  score: integer("score").default(0),
  status: text("status").default("New"), // New, Contacted, Converted
  sourceLink: text("source_link"),
  publicationDate: timestamp("publication_date"),
  assignedOfficerId: integer("assigned_officer_id").references(() => officers.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  status: text("status").default("Pending"), // Pending, In Progress, Completed
  priority: text("priority").default("Medium"), // Low, Medium, High, Urgent
  progress: integer("progress").default(0), // 0-100
  dueDate: timestamp("due_date"),
  leadId: integer("lead_id").references(() => leads.id),
  assignedToId: integer("assigned_to_id"), // Can refer to officer or contractor (loose reference for simplicity or need generic)
  assignedType: text("assigned_type"), // "Officer" or "Contractor"
  createdById: integer("created_by_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Messages table
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").references(() => users.id).notNull(),
  receiverId: integer("receiver_id").references(() => users.id).notNull(),
  subject: text("subject"),
  content: text("content").notNull(),
  isRead: boolean("is_read").default(false),
  parentMessageId: integer("parent_message_id").references(() => messages.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Reports table
export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  type: text("type").notNull(), // "task", "lead", "contractor", "officer", "custom"
  generatedBy: integer("generated_by").references(() => users.id),
  reportData: jsonb("report_data").$type<Record<string, any>>(),
  dateFrom: timestamp("date_from"),
  dateTo: timestamp("date_to"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Notifications table
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").default("info"), // info, success, warning, error
  isRead: boolean("is_read").default(false),
  link: text("link"),
  createdAt: timestamp("created_at").defaultNow(),
});


// === SCHEMAS ===

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true, lastLogin: true });
export const insertOfficerSchema = createInsertSchema(officers).omit({ id: true });
export const insertContractorSchema = createInsertSchema(contractors).omit({ id: true });
export const insertCustomerSchema = createInsertSchema(customers).omit({ id: true });
export const insertLeadSchema = createInsertSchema(leads).omit({ id: true, createdAt: true });
export const insertTaskSchema = createInsertSchema(tasks).omit({ id: true, createdAt: true, updatedAt: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, createdAt: true });
export const insertReportSchema = createInsertSchema(reports).omit({ id: true, createdAt: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, createdAt: true });

// === TYPES ===

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Officer = typeof officers.$inferSelect;
export type InsertOfficer = z.infer<typeof insertOfficerSchema>;

export type Contractor = typeof contractors.$inferSelect;
export type InsertContractor = z.infer<typeof insertContractorSchema>;

export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;

export type Lead = typeof leads.$inferSelect;
export type InsertLead = z.infer<typeof insertLeadSchema>;

export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type Report = typeof reports.$inferSelect;
export type InsertReport = z.infer<typeof insertReportSchema>;

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

// Request types
export type CreateLeadRequest = InsertLead;
export type UpdateLeadRequest = Partial<InsertLead>;
export type CreateOfficerRequest = InsertOfficer;
export type CreateContractorRequest = InsertContractor;
export type CreateCustomerRequest = InsertCustomer;
export type CreateTaskRequest = InsertTask;
export type UpdateTaskRequest = Partial<InsertTask>;
export type CreateMessageRequest = InsertMessage;
export type CreateReportRequest = InsertReport;
export type CreateNotificationRequest = InsertNotification;
export type LoginRequest = { email: string; password: string };
export type RegisterRequest = InsertUser;

// API Response Types
export type LeadResponse = Lead & { assignedOfficer?: Officer | null };
export type TaskResponse = Task & { lead?: Lead | null; assignedTo?: User | null };
export type MessageResponse = Message & { sender?: User | null; receiver?: User | null };
export type ContractorResponse = Contractor & { user?: User | null };
export type UserResponse = Omit<User, 'password'>;

