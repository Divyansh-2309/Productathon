
import { z } from 'zod';
import { 
  insertLeadSchema, 
  insertOfficerSchema, 
  insertContractorSchema, 
  insertTaskSchema,
  leads,
  officers,
  contractors,
  tasks
} from './schema';

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

// ============================================
// API CONTRACT
// ============================================
export const api = {
  leads: {
    list: {
      method: 'GET' as const,
      path: '/api/leads' as const,
      input: z.object({
        status: z.string().optional(),
        minScore: z.coerce.number().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof leads.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/leads/:id' as const,
      responses: {
        200: z.custom<typeof leads.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/leads' as const,
      input: insertLeadSchema,
      responses: {
        201: z.custom<typeof leads.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/leads/:id' as const,
      input: insertLeadSchema.partial(),
      responses: {
        200: z.custom<typeof leads.$inferSelect>(),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
    fetch: {
      method: 'POST' as const,
      path: '/api/leads/fetch' as const,
      input: z.object({}), // No input needed, triggers background fetch
      responses: {
        200: z.object({ message: z.string(), count: z.number() }),
      },
    },
    assign: {
      method: 'POST' as const,
      path: '/api/leads/:id/assign' as const,
      input: z.object({ officerId: z.number() }),
      responses: {
        200: z.custom<typeof leads.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    notify: {
      method: 'POST' as const,
      path: '/api/leads/:id/notify' as const,
      input: z.object({}),
      responses: {
        200: z.object({ success: z.boolean(), message: z.string() }),
      },
    }
  },
  officers: {
    list: {
      method: 'GET' as const,
      path: '/api/officers' as const,
      responses: {
        200: z.array(z.custom<typeof officers.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/officers' as const,
      input: insertOfficerSchema,
      responses: {
        201: z.custom<typeof officers.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  contractors: {
    list: {
      method: 'GET' as const,
      path: '/api/contractors' as const,
      responses: {
        200: z.array(z.custom<typeof contractors.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/contractors' as const,
      input: insertContractorSchema,
      responses: {
        201: z.custom<typeof contractors.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  tasks: {
    list: {
      method: 'GET' as const,
      path: '/api/tasks' as const,
      responses: {
        200: z.array(z.custom<typeof tasks.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/tasks' as const,
      input: insertTaskSchema,
      responses: {
        201: z.custom<typeof tasks.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/tasks/:id' as const,
      input: insertTaskSchema.partial(),
      responses: {
        200: z.custom<typeof tasks.$inferSelect>(),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
