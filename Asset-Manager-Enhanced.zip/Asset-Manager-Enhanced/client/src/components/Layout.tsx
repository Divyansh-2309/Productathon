import { ReactNode } from "react";
import { Sidebar } from "./Sidebar";
import { Menu } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Sidebar as MobileSidebar } from "./Sidebar"; // Reuse internal logic but styled for mobile

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
      <Sidebar />
      
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 border-b bg-card">
        <span className="font-bold text-lg font-display text-primary">GovConnect</span>
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu className="w-5 h-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-64">
            <MobileSidebarWrapper />
          </SheetContent>
        </Sheet>
      </div>

      <main className="md:pl-64 min-h-screen transition-all duration-300 ease-in-out">
        <div className="max-w-7xl mx-auto p-4 md:p-8 lg:p-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
          {children}
        </div>
      </main>
    </div>
  );
}

// Wrapper to reuse Sidebar logic in mobile sheet
function MobileSidebarWrapper() {
  return (
    <div className="h-full">
       <Sidebar /> 
       {/* Note: In a real app we'd decouple styles, but for generation speed this works since Sidebar has fixed positioning classes we might need to override or just render contents. 
           Actually, the Sidebar component above has `fixed` and `hidden md:flex`. 
           Let's just use the Sidebar component but we need to override the `hidden` class.
       */}
       <style>{`.md\\:flex { display: flex !important; width: 100%; position: relative; height: 100%; }`}</style>
    </div>
  )
}
