import { Layout } from "@/components/Layout";
import { useLeads } from "@/hooks/use-leads";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Search, MapPin, Building2, ChevronRight, Filter } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";

export default function LeadsList() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [search, setSearch] = useState("");
  const { data: leads, isLoading } = useLeads();

  const filteredLeads = leads?.filter(lead => {
    const matchesStatus = statusFilter === "all" || lead.status === statusFilter;
    const matchesSearch = lead.companyName.toLowerCase().includes(search.toLowerCase()) || 
                          lead.industry?.toLowerCase().includes(search.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold font-display text-slate-900">Leads</h1>
            <p className="text-muted-foreground mt-1">Discover and manage procurement opportunities.</p>
          </div>
        </div>

        {/* Filters */}
        <Card className="border-none shadow-sm bg-white/50 backdrop-blur-sm">
          <CardContent className="p-4 flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input 
                placeholder="Search companies or industries..." 
                className="pl-9 bg-white border-slate-200" 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <div className="w-full md:w-48">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="bg-white border-slate-200">
                  <Filter className="w-4 h-4 mr-2 text-muted-foreground" />
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="New">New</SelectItem>
                  <SelectItem value="Contacted">Contacted</SelectItem>
                  <SelectItem value="Converted">Converted</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* List */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-12">Loading leads...</div>
          ) : filteredLeads?.length === 0 ? (
             <div className="text-center py-12 text-muted-foreground">No leads found matching your filters.</div>
          ) : (
            filteredLeads?.map((lead) => (
              <Link key={lead.id} href={`/leads/${lead.id}`}>
                <div className="group bg-white rounded-xl border border-slate-100 p-5 shadow-sm hover:shadow-md hover:border-primary/30 transition-all duration-200 cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <h3 className="font-bold text-lg text-slate-900 group-hover:text-primary transition-colors">{lead.companyName}</h3>
                      {lead.status === "New" && <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-200 border-none shadow-none">New</Badge>}
                      {lead.status === "Converted" && <Badge className="bg-green-100 text-green-700 hover:bg-green-200 border-none shadow-none">Converted</Badge>}
                    </div>
                    <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {lead.location}</span>
                      <span className="flex items-center gap-1"><Building2 className="w-3.5 h-3.5" /> {lead.industry}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="text-right hidden md:block">
                      <div className="text-sm font-medium text-slate-900">{lead.confidence}% Match</div>
                      <div className="text-xs text-muted-foreground">Confidence Score</div>
                    </div>
                    <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center group-hover:bg-primary group-hover:text-white transition-colors">
                      <ChevronRight className="w-5 h-5" />
                    </div>
                  </div>
                </div>
              </Link>
            ))
          )}
        </div>
      </div>
    </Layout>
  );
}
