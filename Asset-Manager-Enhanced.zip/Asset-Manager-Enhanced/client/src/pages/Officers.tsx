import { Layout } from "@/components/Layout";
import { useOfficers, useCreateOfficer } from "@/hooks/use-officers";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Plus, Mail, Phone, Map } from "lucide-react";
import { useState } from "react";
import { type InsertOfficer } from "@shared/routes";

export default function Officers() {
  const { data: officers, isLoading } = useOfficers();
  const { mutate: createOfficer, isPending } = useCreateOfficer();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<InsertOfficer>({ name: "", email: "", phone: "", region: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createOfficer(form, {
      onSuccess: () => {
        setOpen(false);
        setForm({ name: "", email: "", phone: "", region: "" });
      }
    });
  };

  return (
    <Layout>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold font-display text-slate-900">Officers</h1>
          <p className="text-muted-foreground mt-1">Manage procurement officers and regional assignments</p>
        </div>
        
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-full shadow-lg shadow-primary/25"><Plus className="w-4 h-4 mr-2" /> Add Officer</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Officer</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input required value={form.name} onChange={e => setForm({...form, name: e.target.value})} placeholder="Jane Doe" />
                </div>
                <div className="space-y-2">
                  <Label>Region</Label>
                  <Input required value={form.region} onChange={e => setForm({...form, region: e.target.value})} placeholder="North-East" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input required type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} placeholder="jane@gov.com" />
              </div>
              <div className="space-y-2">
                <Label>Phone</Label>
                <Input required value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} placeholder="+1 (555) 000-0000" />
              </div>
              <Button type="submit" className="w-full" disabled={isPending}>{isPending ? "Creating..." : "Create Officer"}</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          <p>Loading officers...</p>
        ) : officers?.map((officer) => (
          <Card key={officer.id} className="border-none shadow-lg shadow-slate-200/50 hover:-translate-y-1 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <Avatar className="h-12 w-12 border-2 border-primary/10">
                  <AvatarFallback className="bg-primary/5 text-primary font-bold">
                    {officer.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-bold text-lg">{officer.name}</h3>
                  <div className="flex items-center text-xs text-muted-foreground bg-slate-100 px-2 py-0.5 rounded-full w-fit mt-1">
                    <Map className="w-3 h-3 mr-1" /> {officer.region}
                  </div>
                </div>
              </div>
              <div className="space-y-2 text-sm text-slate-600">
                <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  {officer.email}
                </div>
                <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  {officer.phone}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </Layout>
  );
}
