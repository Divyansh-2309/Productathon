import { Layout } from "@/components/Layout";
import { useLeads, useFetchLeads } from "@/hooks/use-leads";
import { useTasks } from "@/hooks/use-tasks";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RefreshCcw, TrendingUp, Users, AlertCircle, Briefcase } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from "recharts";
import { motion } from "framer-motion";
import { Link } from "wouter";

export default function Dashboard() {
  const { data: leads, isLoading: loadingLeads } = useLeads();
  const { data: tasks } = useTasks();
  const { mutate: refreshLeads, isPending: isRefreshing } = useFetchLeads();

  const stats = [
    { label: "Total Leads", value: leads?.length || 0, icon: Users, color: "text-blue-600", bg: "bg-blue-100" },
    { label: "High Confidence", value: leads?.filter(l => (l.confidence || 0) > 80).length || 0, icon: TrendingUp, color: "text-green-600", bg: "bg-green-100" },
    { label: "Pending Tasks", value: tasks?.filter(t => t.status === "Pending").length || 0, icon: AlertCircle, color: "text-orange-600", bg: "bg-orange-100" },
    { label: "Converted", value: leads?.filter(l => l.status === "Converted").length || 0, icon: Briefcase, color: "text-purple-600", bg: "bg-purple-100" },
  ];

  const pieData = [
    { name: 'New', value: leads?.filter(l => l.status === 'New').length || 0 },
    { name: 'Contacted', value: leads?.filter(l => l.status === 'Contacted').length || 0 },
    { name: 'Converted', value: leads?.filter(l => l.status === 'Converted').length || 0 },
  ];
  const COLORS = ['#6366f1', '#a855f7', '#10b981'];

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold font-display tracking-tight text-slate-900">Dashboard Overview</h1>
            <p className="text-muted-foreground mt-1">Welcome back, here's what's happening today.</p>
          </div>
          <Button 
            onClick={() => refreshLeads()} 
            disabled={isRefreshing}
            className="rounded-full shadow-lg shadow-primary/20"
          >
            <RefreshCcw className={`mr-2 h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh Leads
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="border-none shadow-lg shadow-slate-200/50 hover:shadow-xl transition-all duration-300">
                <CardContent className="p-6 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{stat.label}</p>
                    <h3 className="text-3xl font-bold mt-2 font-display">{stat.value}</h3>
                  </div>
                  <div className={`p-4 rounded-xl ${stat.bg} ${stat.color}`}>
                    <stat.icon className="w-6 h-6" />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="border-none shadow-lg shadow-slate-200/50">
            <CardHeader>
              <CardTitle>Lead Status Distribution</CardTitle>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg shadow-slate-200/50">
            <CardHeader>
              <CardTitle>Recent High-Intent Leads</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {leads?.filter(l => (l.confidence || 0) > 70).slice(0, 5).map(lead => (
                  <Link key={lead.id} href={`/leads/${lead.id}`}>
                    <div className="flex items-center justify-between p-4 rounded-xl bg-slate-50 hover:bg-indigo-50 transition-colors cursor-pointer group">
                      <div>
                        <h4 className="font-semibold text-slate-900 group-hover:text-primary transition-colors">{lead.companyName}</h4>
                        <p className="text-sm text-muted-foreground">{lead.industry} • {lead.location}</p>
                      </div>
                      <div className="text-right">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          {lead.confidence}% Match
                        </span>
                      </div>
                    </div>
                  </Link>
                ))}
                {leads?.length === 0 && <p className="text-muted-foreground text-center py-8">No leads found.</p>}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
