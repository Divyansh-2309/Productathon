import { Layout } from "@/components/Layout";
import { useContractors, useCreateContractor } from "@/hooks/use-contractors";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Plus, Briefcase, Mail, Phone } from "lucide-react";
import { useState } from "react";
import { type InsertContractor } from "@shared/routes";

export default function Contractors() {
  const { data: contractors, isLoading } = useContractors();
  const { mutate: createContractor, isPending } = useCreateContractor();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<InsertContractor>({ name: "", company: "", role: "", email: "", phone: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createContractor(form, {
      onSuccess: () => {
        setOpen(false);
        setForm({ name: "", company: "", role: "", email: "", phone: "" });
      }
    });
  };

  return (
    <Layout>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold font-display text-slate-900">Contractors</h1>
          <p className="text-muted-foreground mt-1">Directory of external contractors and vendors</p>
        </div>
        
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-full shadow-lg shadow-primary/25"><Plus className="w-4 h-4 mr-2" /> Add Contractor</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Contractor</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input required value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Company</Label>
                  <Input required value={form.company} onChange={e => setForm({...form, company: e.target.value})} />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Role</Label>
                <Input required value={form.role} onChange={e => setForm({...form, role: e.target.value})} placeholder="e.g. Consultant" />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input required type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Phone</Label>
                <Input required value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} />
              </div>
              <Button type="submit" className="w-full" disabled={isPending}>{isPending ? "Adding..." : "Add Contractor"}</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          <p>Loading contractors...</p>
        ) : contractors?.map((contractor) => (
          <Card key={contractor.id} className="border-none shadow-lg shadow-slate-200/50 group hover:border-primary/20 transition-all">
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarFallback className="bg-slate-100 text-slate-700">
                      {contractor.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-bold">{contractor.name}</h3>
                    <p className="text-xs text-muted-foreground">{contractor.role}</p>
                  </div>
                </div>
                <div className="bg-indigo-50 text-indigo-700 px-2 py-1 rounded text-xs font-medium">
                  {contractor.company}
                </div>
              </div>
              
              <div className="space-y-2 mt-4 pt-4 border-t border-slate-100">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Mail className="w-4 h-4" /> {contractor.email}
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Phone className="w-4 h-4" /> {contractor.phone}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </Layout>
  );
}
