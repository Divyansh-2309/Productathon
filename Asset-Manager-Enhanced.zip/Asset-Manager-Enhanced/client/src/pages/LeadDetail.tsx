import { Layout } from "@/components/Layout";
import { useLead, useAssignOfficer, useNotifyLead } from "@/hooks/use-leads";
import { useOfficers } from "@/hooks/use-officers";
import { useCreateTask } from "@/hooks/use-tasks";
import { useRoute } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Building2, MapPin, Globe, UserCheck, Bell, Calendar, Percent } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { format } from "date-fns";
import { type InsertTask } from "@shared/routes";

export default function LeadDetail() {
  const [, params] = useRoute("/leads/:id");
  const leadId = parseInt(params?.id || "0");
  const { data: lead, isLoading } = useLead(leadId);
  const { data: officers } = useOfficers();
  
  const { mutate: assignOfficer, isPending: isAssigning } = useAssignOfficer();
  const { mutate: notify, isPending: isNotifying } = useNotifyLead();
  const { mutate: createTask, isPending: isCreatingTask } = useCreateTask();

  const [selectedOfficer, setSelectedOfficer] = useState<string>("");
  const [taskForm, setTaskForm] = useState<Partial<InsertTask>>({ title: "", description: "" });
  const [taskDialogOpen, setTaskDialogOpen] = useState(false);

  if (isLoading) return <div className="flex h-screen items-center justify-center"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>;
  if (!lead) return <div className="p-8 text-center">Lead not found</div>;

  return (
    <Layout>
      <div className="space-y-6 max-w-5xl mx-auto">
        <Link href="/leads" className="inline-flex items-center text-sm text-muted-foreground hover:text-primary transition-colors">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Leads
        </Link>

        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start gap-4">
          <div>
            <h1 className="text-4xl font-bold font-display text-slate-900">{lead.companyName}</h1>
            <div className="flex flex-wrap gap-3 mt-3">
              <Badge variant="secondary" className="px-3 py-1"><MapPin className="w-3 h-3 mr-1" /> {lead.location}</Badge>
              <Badge variant="secondary" className="px-3 py-1"><Building2 className="w-3 h-3 mr-1" /> {lead.industry}</Badge>
              <Badge variant={lead.confidence && lead.confidence > 80 ? "default" : "outline"} className="px-3 py-1">
                <Percent className="w-3 h-3 mr-1" /> {lead.confidence}% Confidence
              </Badge>
            </div>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => notify(leadId)} disabled={isNotifying}>
              <Bell className="w-4 h-4 mr-2" /> {isNotifying ? "Sending..." : "Notify Officer"}
            </Button>
            
            <Dialog open={taskDialogOpen} onOpenChange={setTaskDialogOpen}>
              <DialogTrigger asChild>
                <Button>Create Task</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>New Task for {lead.companyName}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>Task Title</Label>
                    <Input 
                      placeholder="Follow up call..." 
                      value={taskForm.title} 
                      onChange={e => setTaskForm({...taskForm, title: e.target.value})} 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Textarea 
                      placeholder="Details..." 
                      value={taskForm.description || ""} 
                      onChange={e => setTaskForm({...taskForm, description: e.target.value})} 
                    />
                  </div>
                  <Button 
                    className="w-full" 
                    onClick={() => {
                      if (!taskForm.title) return;
                      createTask({
                        title: taskForm.title!,
                        description: taskForm.description,
                        leadId: lead.id,
                        status: "Pending"
                      }, { onSuccess: () => setTaskDialogOpen(false) });
                    }}
                    disabled={isCreatingTask}
                  >
                    {isCreatingTask ? "Creating..." : "Create Task"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Main Info */}
          <Card className="md:col-span-2 border-none shadow-lg shadow-slate-200/50">
            <CardHeader>
              <CardTitle>Lead Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Signal Source</label>
                  <p className="mt-1 font-medium">{lead.signal || "N/A"}</p>
                </div>
                <div>
                  <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Published Date</label>
                  <p className="mt-1 font-medium">{lead.publicationDate ? format(new Date(lead.publicationDate), 'PPP') : "N/A"}</p>
                </div>
              </div>
              
              <div>
                <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Source Link</label>
                <a href={lead.sourceLink || "#"} target="_blank" className="flex items-center mt-1 text-primary hover:underline truncate">
                  <Globe className="w-4 h-4 mr-2" /> {lead.sourceLink || "No link available"}
                </a>
              </div>

              <div>
                <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Recommended Products</label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {lead.recommendedProducts?.map((prod, i) => (
                    <span key={i} className="bg-slate-100 text-slate-700 px-3 py-1 rounded-md text-sm font-medium border border-slate-200">
                      {prod}
                    </span>
                  ))}
                  {(!lead.recommendedProducts || lead.recommendedProducts.length === 0) && <span className="text-muted-foreground text-sm">None</span>}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Sidebar Actions */}
          <div className="space-y-6">
            <Card className="border-none shadow-lg shadow-slate-200/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserCheck className="w-5 h-5 text-primary" /> Assignment
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Assigned Officer</Label>
                    <Select value={selectedOfficer} onValueChange={setSelectedOfficer}>
                      <SelectTrigger>
                        <SelectValue placeholder={lead.assignedOfficerId ? "Change officer" : "Select officer"} />
                      </SelectTrigger>
                      <SelectContent>
                        {officers?.map((officer) => (
                          <SelectItem key={officer.id} value={String(officer.id)}>
                            {officer.name} ({officer.region})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button 
                    className="w-full" 
                    disabled={!selectedOfficer || isAssigning}
                    onClick={() => assignOfficer({ leadId: lead.id, officerId: parseInt(selectedOfficer) })}
                  >
                    {isAssigning ? "Assigning..." : "Confirm Assignment"}
                  </Button>
                  
                  {lead.assignedOfficerId && (
                    <div className="bg-green-50 text-green-700 p-3 rounded-lg text-sm flex items-center mt-2">
                      Currently assigned to Officer #{lead.assignedOfficerId}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
