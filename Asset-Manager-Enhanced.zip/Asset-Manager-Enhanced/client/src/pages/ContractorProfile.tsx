import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import Layout from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { 
  User, Mail, Phone, Building2, DollarSign, Star, 
  Award, CheckCircle2, Clock, MessageSquare, Briefcase 
} from "lucide-react";
import type { Contractor, Task } from "@/../../shared/schema";

interface ContractorWithTasks extends Contractor {
  tasks?: Task[];
}

export default function ContractorProfile() {
  const { id } = useParams();

  const { data: contractor, isLoading } = useQuery<ContractorWithTasks>({
    queryKey: [`/api/contractors/${id}`],
  });

  if (isLoading) {
    return (
      <Layout>
        <div className="p-6 flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading contractor profile...</p>
          </div>
        </div>
      </Layout>
    );
  }

  if (!contractor) {
    return (
      <Layout>
        <div className="p-6 text-center">
          <p className="text-muted-foreground">Contractor not found</p>
        </div>
      </Layout>
    );
  }

  const activeTasks = contractor.tasks?.filter(t => t.status !== "Completed").length || 0;
  const completionRate = contractor.completedProjects > 0 
    ? Math.round((contractor.completedProjects / (contractor.completedProjects + activeTasks)) * 100)
    : 0;

  return (
    <Layout>
      <div className="p-6 space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Header Card */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-6">
                <Avatar className="h-32 w-32">
                  <AvatarImage src={contractor.profileImage || undefined} />
                  <AvatarFallback className="text-4xl">
                    {contractor.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>

                <div className="flex-1 space-y-4">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <h1 className="text-3xl font-bold">{contractor.name}</h1>
                      <Badge variant={contractor.availability === "Available" ? "default" : "secondary"}>
                        {contractor.availability}
                      </Badge>
                    </div>
                    <p className="text-lg text-muted-foreground">{contractor.role}</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center gap-2 text-sm">
                      <Building2 className="h-4 w-4 text-muted-foreground" />
                      <span>{contractor.company}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span>{contractor.email}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span>{contractor.phone}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <DollarSign className="h-4 w-4 text-muted-foreground" />
                      <span>${contractor.hourlyRate}/hour</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`h-5 w-5 ${
                            i < (contractor.rating || 0)
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-300"
                          }`}
                        />
                      ))}
                      <span className="ml-2 text-sm text-muted-foreground">
                        {contractor.rating}/5
                      </span>
                    </div>
                    <Separator orientation="vertical" className="h-6" />
                    <div className="flex items-center gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-green-500" />
                      <span>{contractor.completedProjects} projects completed</span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button>
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Send Message
                    </Button>
                    <Button variant="outline">
                      <Briefcase className="mr-2 h-4 w-4" />
                      Assign Task
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Active Tasks</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{activeTasks}</div>
                <p className="text-xs text-muted-foreground">Currently working on</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Completion Rate</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{completionRate}%</div>
                <Progress value={completionRate} className="mt-2" />
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Certifications</CardTitle>
                <Award className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {contractor.certifications?.length || 0}
                </div>
                <p className="text-xs text-muted-foreground">Verified credentials</p>
              </CardContent>
            </Card>
          </div>

          {/* Bio */}
          {contractor.bio && (
            <Card>
              <CardHeader>
                <CardTitle>About</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{contractor.bio}</p>
              </CardContent>
            </Card>
          )}

          {/* Skills */}
          {contractor.skills && contractor.skills.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Skills & Expertise</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {contractor.skills.map((skill, index) => (
                    <Badge key={index} variant="secondary">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Certifications */}
          {contractor.certifications && contractor.certifications.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Certifications</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {contractor.certifications.map((cert, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Award className="h-4 w-4 text-primary" />
                      <span>{cert}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recent Tasks */}
          {contractor.tasks && contractor.tasks.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Recent Tasks</CardTitle>
                <CardDescription>Tasks assigned to this contractor</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {contractor.tasks.map((task) => (
                    <div key={task.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="space-y-1">
                        <p className="font-medium">{task.title}</p>
                        <p className="text-sm text-muted-foreground">{task.description}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge variant={
                            task.status === "Completed" ? "default" :
                            task.status === "In Progress" ? "secondary" :
                            "outline"
                          }>
                            {task.status}
                          </Badge>
                          {task.priority && (
                            <Badge variant={
                              task.priority === "Urgent" ? "destructive" :
                              task.priority === "High" ? "default" :
                              "secondary"
                            }>
                              {task.priority}
                            </Badge>
                          )}
                        </div>
                      </div>
                      {task.progress !== undefined && (
                        <div className="w-32">
                          <div className="text-sm font-medium mb-1">{task.progress}%</div>
                          <Progress value={task.progress} />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </motion.div>
      </div>
    </Layout>
  );
}
