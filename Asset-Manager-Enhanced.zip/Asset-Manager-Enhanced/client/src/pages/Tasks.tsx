import { Layout } from "@/components/Layout";
import { useTasks, useUpdateTask } from "@/hooks/use-tasks";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd"; // Not installed, using simple columns instead for simplicity per requirements
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Circle, Clock } from "lucide-react";

export default function Tasks() {
  const { data: tasks, isLoading } = useTasks();
  const { mutate: updateTask } = useUpdateTask();

  const columns = [
    { id: "Pending", title: "To Do", icon: Circle, color: "text-slate-500" },
    { id: "In Progress", title: "In Progress", icon: Clock, color: "text-blue-500" },
    { id: "Completed", title: "Done", icon: CheckCircle2, color: "text-green-500" },
  ];

  if (isLoading) return <Layout><div>Loading...</div></Layout>;

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold font-display text-slate-900">Task Board</h1>
        <p className="text-muted-foreground mt-1">Track procurement workflows and officer assignments</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
        {columns.map((col) => {
          const colTasks = tasks?.filter(t => t.status === col.id) || [];
          
          return (
            <div key={col.id} className="flex flex-col bg-slate-50/50 rounded-2xl border border-slate-200/60 p-4">
              <div className="flex items-center justify-between mb-4 px-2">
                <div className="flex items-center gap-2">
                  <col.icon className={`w-5 h-5 ${col.color}`} />
                  <h3 className="font-semibold text-slate-700">{col.title}</h3>
                </div>
                <Badge variant="secondary" className="bg-white">{colTasks.length}</Badge>
              </div>

              <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar">
                {colTasks.map(task => (
                  <Card key={task.id} className="border-none shadow-sm hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-4">
                      <h4 className="font-semibold text-sm mb-1">{task.title}</h4>
                      <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{task.description}</p>
                      
                      <div className="flex gap-2">
                        {col.id !== "Pending" && (
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-6 text-[10px] px-2 bg-slate-100 hover:bg-slate-200"
                            onClick={() => updateTask({ id: task.id, status: "Pending" })}
                          >
                            Move Back
                          </Button>
                        )}
                        
                        {col.id !== "Completed" && (
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-6 text-[10px] px-2 bg-primary/10 text-primary hover:bg-primary/20 ml-auto"
                            onClick={() => updateTask({ 
                              id: task.id, 
                              status: col.id === "Pending" ? "In Progress" : "Completed" 
                            })}
                          >
                            Advance
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
                {colTasks.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground text-sm border-2 border-dashed border-slate-200 rounded-xl">
                    No tasks
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </Layout>
  );
}
