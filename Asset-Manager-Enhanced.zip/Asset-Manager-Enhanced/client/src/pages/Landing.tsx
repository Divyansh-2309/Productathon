import { Link } from "wouter";
import { ArrowRight, BarChart3, ShieldCheck, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 to-white flex flex-col items-center justify-center p-6 text-center">
      <div className="max-w-4xl w-full space-y-8 animate-in fade-in zoom-in duration-700">
        
        {/* Logo/Brand */}
        <div className="mx-auto w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-indigo-700 flex items-center justify-center shadow-2xl shadow-primary/30 mb-8 transform hover:scale-110 transition-transform duration-300">
          <ShieldCheck className="w-8 h-8 text-white" />
        </div>

        <h1 className="text-5xl md:text-7xl font-bold font-display tracking-tight text-slate-900 drop-shadow-sm">
          Gov<span className="text-primary">Connect</span>
        </h1>
        
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
          The intelligent platform for managing government tenders, contractor relations, and procurement workflows with AI-driven insights.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
          <Link href="/dashboard">
            <Button size="lg" className="h-14 px-8 text-lg rounded-full shadow-xl shadow-primary/20 hover:shadow-2xl hover:shadow-primary/30 hover:-translate-y-1 transition-all duration-300">
              Enter Dashboard <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
          <Button variant="outline" size="lg" className="h-14 px-8 text-lg rounded-full border-2 hover:bg-slate-50">
            View Documentation
          </Button>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20 text-left">
          {[
            { icon: Zap, title: "Real-time Signals", desc: "Instant alerts on new tenders and procurement opportunities." },
            { icon: BarChart3, title: "Smart Analytics", desc: "Track conversion rates and officer performance metrics." },
            { icon: ShieldCheck, title: "Compliance Ready", desc: "Built-in workflows to ensure regulatory compliance." }
          ].map((feature, idx) => (
            <div key={idx} className="p-6 bg-white rounded-2xl shadow-lg shadow-slate-200/50 border border-slate-100 hover:border-primary/20 transition-colors">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-4 text-primary">
                <feature.icon className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-lg mb-2">{feature.title}</h3>
              <p className="text-muted-foreground text-sm">{feature.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
