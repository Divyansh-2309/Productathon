import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertContractor } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useContractors() {
  return useQuery({
    queryKey: [api.contractors.list.path],
    queryFn: async () => {
      const res = await fetch(api.contractors.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch contractors");
      return api.contractors.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateContractor() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertContractor) => {
      const res = await fetch(api.contractors.create.path, {
        method: api.contractors.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create contractor");
      return api.contractors.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.contractors.list.path] });
      toast({ title: "Success", description: "Contractor added successfully" });
    },
  });
}
