import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertOfficer } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useOfficers() {
  return useQuery({
    queryKey: [api.officers.list.path],
    queryFn: async () => {
      const res = await fetch(api.officers.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch officers");
      return api.officers.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateOfficer() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertOfficer) => {
      const res = await fetch(api.officers.create.path, {
        method: api.officers.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create officer");
      return api.officers.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.officers.list.path] });
      toast({ title: "Success", description: "Officer added successfully" });
    },
  });
}
