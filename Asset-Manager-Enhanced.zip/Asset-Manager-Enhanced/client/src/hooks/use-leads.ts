import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertLead } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useLeads(filters?: { status?: string; minScore?: number }) {
  // Construct query string for cache key uniqueness
  const queryString = filters ? JSON.stringify(filters) : "";
  
  return useQuery({
    queryKey: [api.leads.list.path, queryString],
    queryFn: async () => {
      // Build URL with query params
      const url = new URL(window.location.origin + api.leads.list.path);
      if (filters?.status) url.searchParams.append("status", filters.status);
      if (filters?.minScore) url.searchParams.append("minScore", filters.minScore.toString());
      
      const res = await fetch(url.toString(), { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch leads");
      return api.leads.list.responses[200].parse(await res.json());
    },
  });
}

export function useLead(id: number) {
  return useQuery({
    queryKey: [api.leads.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.leads.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch lead");
      return api.leads.get.responses[200].parse(await res.json());
    },
    enabled: !isNaN(id),
  });
}

export function useCreateLead() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertLead) => {
      const res = await fetch(api.leads.create.path, {
        method: api.leads.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create lead");
      return api.leads.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.leads.list.path] });
      toast({ title: "Success", description: "Lead created successfully" });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });
}

export function useUpdateLead() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number } & Partial<InsertLead>) => {
      const url = buildUrl(api.leads.update.path, { id });
      const res = await fetch(url, {
        method: api.leads.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update lead");
      return api.leads.update.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.leads.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.leads.get.path, data.id] });
      toast({ title: "Success", description: "Lead updated" });
    },
  });
}

export function useAssignOfficer() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ leadId, officerId }: { leadId: number; officerId: number }) => {
      const url = buildUrl(api.leads.assign.path, { id: leadId });
      const res = await fetch(url, {
        method: api.leads.assign.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ officerId }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to assign officer");
      return api.leads.assign.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.leads.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.leads.get.path, data.id] });
      toast({ title: "Assigned", description: "Officer assigned successfully" });
    },
  });
}

export function useFetchLeads() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.leads.fetch.path, {
        method: api.leads.fetch.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch external leads");
      return api.leads.fetch.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.leads.list.path] });
      toast({ title: "Refreshed", description: data.message });
    },
  });
}

export function useNotifyLead() {
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.leads.notify.path, { id });
      const res = await fetch(url, {
        method: api.leads.notify.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Notification failed");
      return api.leads.notify.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      toast({ title: "Sent", description: data.message });
    },
  });
}
