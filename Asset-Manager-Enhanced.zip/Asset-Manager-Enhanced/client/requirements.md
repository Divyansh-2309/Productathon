## Packages
framer-motion | Complex page transitions and layout animations
recharts | Data visualization for dashboard statistics
date-fns | Date formatting for leads and tasks
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility to merge Tailwind classes without conflicts

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-sans)"],
}
