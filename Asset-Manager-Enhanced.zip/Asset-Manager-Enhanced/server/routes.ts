
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { leadAgent } from "./lead_agent";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // === Leads ===
  app.get(api.leads.list.path, async (req, res) => {
    const status = req.query.status as string | undefined;
    const minScore = req.query.minScore ? Number(req.query.minScore) : undefined;
    const leads = await storage.getLeads(status, minScore);
    res.json(leads);
  });

  app.get(api.leads.get.path, async (req, res) => {
    const lead = await storage.getLead(Number(req.params.id));
    if (!lead) return res.status(404).json({ message: "Lead not found" });
    res.json(lead);
  });

  app.post(api.leads.create.path, async (req, res) => {
    try {
      const input = api.leads.create.input.parse(req.body);
      const lead = await storage.createLead(input);
      res.status(201).json(lead);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.put(api.leads.update.path, async (req, res) => {
    try {
      const input = api.leads.update.input.parse(req.body);
      const lead = await storage.updateLead(Number(req.params.id), input);
      res.json(lead);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.post(api.leads.fetch.path, async (req, res) => {
    try {
      const result = await leadAgent.fetchLeads();
      res.json(result);
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Failed to fetch leads" });
    }
  });

  app.post(api.leads.assign.path, async (req, res) => {
    const { officerId } = req.body;
    const lead = await storage.updateLead(Number(req.params.id), { assignedOfficerId: officerId });
    res.json(lead);
  });

  app.post(api.leads.notify.path, async (req, res) => {
    const leadId = req.params.id;
    const lead = await storage.getLead(Number(leadId));
    
    // Simulate WhatsApp Notification
    console.log(`
      >>> WHATSAPP NOTIFICATION SENT <<<
      To: Officer (Region Head)
      Body: New High Value Lead Detected!
      Company: ${lead?.companyName}
      Score: ${lead?.score}
      Product: ${lead?.recommendedProducts}
      Link: ${lead?.sourceLink}
      >>> END NOTIFICATION <<<
    `);
    
    res.json({ success: true, message: "Notification sent (simulated)" });
  });

  // === Officers ===
  app.get(api.officers.list.path, async (req, res) => {
    const officers = await storage.getOfficers();
    res.json(officers);
  });

  app.post(api.officers.create.path, async (req, res) => {
    const input = api.officers.create.input.parse(req.body);
    const officer = await storage.createOfficer(input);
    res.status(201).json(officer);
  });

  // === Contractors ===
  app.get(api.contractors.list.path, async (req, res) => {
    const contractors = await storage.getContractors();
    res.json(contractors);
  });

  app.post(api.contractors.create.path, async (req, res) => {
    const input = api.contractors.create.input.parse(req.body);
    const contractor = await storage.createContractor(input);
    res.status(201).json(contractor);
  });

  // === Tasks ===
  app.get(api.tasks.list.path, async (req, res) => {
    const tasks = await storage.getTasks();
    res.json(tasks);
  });

  app.post(api.tasks.create.path, async (req, res) => {
    const input = api.tasks.create.input.parse(req.body);
    const task = await storage.createTask(input);
    res.status(201).json(task);
  });
  
  app.put(api.tasks.update.path, async (req, res) => {
    const input = api.tasks.update.input.parse(req.body);
    const task = await storage.updateTask(Number(req.params.id), input);
    res.json(task);
  });

  // === SEED DATA ===
  const existingOfficers = await storage.getOfficers();
  if (existingOfficers.length === 0) {
    await storage.createOfficer({ name: "Rajesh Kumar", region: "North", email: "rajesh@example.com", phone: "+919876543210" });
    await storage.createOfficer({ name: "Anita Singh", region: "West", email: "anita@example.com", phone: "+919876543211" });
  }
  
  const existingContractors = await storage.getContractors();
  if (existingContractors.length === 0) {
    await storage.createContractor({ name: "BuildWell Pvt Ltd", company: "BuildWell", role: "Construction", email: "contact@buildwell.com", phone: "011-23456789" });
  }

  // Initial Lead Fetch
  // Don't await this so it doesn't block startup, but trigger it
  leadAgent.fetchLeads().catch(console.error);

  return httpServer;
}
