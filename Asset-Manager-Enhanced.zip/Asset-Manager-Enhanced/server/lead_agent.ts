
import Parser from 'rss-parser';
import axios from 'axios';
import { storage } from './storage';
import { type InsertLead } from '@shared/schema';

// Keywords to track
const KEYWORDS = [
  'boiler installation',
  'steel plant expansion',
  'furnace oil tender',
  'bitumen procurement',
  'captive power plant',
  'marine bunker fuel',
  'hexane solvent'
];

// Product inference rules
const PRODUCT_MAPPING: Record<string, string[]> = {
  'boiler': ['Furnace Oil', 'LSHS'],
  'furnace': ['Furnace Oil', 'LSHS'],
  'road': ['Bitumen'],
  'highway': ['Bitumen'],
  'marine': ['Bunker Fuel'],
  'vessel': ['Bunker Fuel'],
  'solvent': ['Hexane'],
  'hexane': ['Hexane'],
  'steel': ['LDO', 'Furnace Oil'],
  'power plant': ['Coal', 'Fuel Oil']
};

class LeadAgent {
  private parser: Parser;

  constructor() {
    this.parser = new Parser();
  }

  // Calculate score based on logic
  private calculateScore(text: string, isTender: boolean, date: Date): number {
    let score = 50; // Base score

    if (isTender) score += 30; // High intent

    // Freshness
    const daysOld = (new Date().getTime() - date.getTime()) / (1000 * 3600 * 24);
    if (daysOld < 3) score += 15;
    else if (daysOld < 7) score += 5;

    // Keyword strength
    const lowerText = text.toLowerCase();
    let matches = 0;
    KEYWORDS.forEach(k => {
      if (lowerText.includes(k)) matches++;
    });
    score += (matches * 10);

    return Math.min(score, 100);
  }

  // Infer products
  private inferProducts(text: string): string[] {
    const products = new Set<string>();
    const lowerText = text.toLowerCase();
    
    Object.entries(PRODUCT_MAPPING).forEach(([key, values]) => {
      if (lowerText.includes(key)) {
        values.forEach(v => products.add(v));
      }
    });

    return Array.from(products);
  }

  // Extract company name (heuristic)
  private extractCompany(title: string): string {
    // Simple heuristic: Text before "announces", "expands", "to build", or split by "-"
    // Real implementation would use NLP
    const splitByDash = title.split(' - ');
    if (splitByDash.length > 1) {
      // Usually "Title - Source" or "Company - Title"
      // Let's guess the first part is often the subject
      return splitByDash[0].trim(); 
    }
    return "Unknown Entity"; // Placeholder
  }

  async fetchLeads() {
    console.log("Starting lead fetch...");
    const leadsToAdd: InsertLead[] = [];

    // 1. Google News RSS for Keywords
    // We'll loop through a few keywords to simulate comprehensive search
    const searchTerms = ['industrial tender', 'plant expansion india', 'boiler procurement']; 
    
    for (const term of searchTerms) {
      try {
        const encoded = encodeURIComponent(term);
        const feedUrl = `https://news.google.com/rss/search?q=${encoded}&hl=en-IN&gl=IN&ceid=IN:en`;
        const feed = await this.parser.parseURL(feedUrl);

        for (const item of feed.items) {
          if (!item.title || !item.link) continue;
          
          const fullText = (item.title + " " + (item.contentSnippet || "")).toLowerCase();
          
          // Check if relevant
          const hasKeyword = KEYWORDS.some(k => fullText.includes(k.split(' ')[0])); // Loose match
          if (!hasKeyword && !fullText.includes("tender")) continue;

          const isTender = fullText.includes("tender") || fullText.includes("procurement");
          const products = this.inferProducts(fullText);
          
          if (products.length === 0 && !isTender) continue; // Skip if no clear signal

          const pubDate = item.pubDate ? new Date(item.pubDate) : new Date();
          
          leadsToAdd.push({
            companyName: this.extractCompany(item.title),
            location: "Unknown", // NLP would allow extraction
            industry: "Industrial",
            signal: isTender ? "Public Tender" : "News Signal",
            recommendedProducts: products,
            confidence: isTender ? 90 : 70,
            score: this.calculateScore(fullText, isTender, pubDate),
            status: "New",
            sourceLink: item.link,
            publicationDate: pubDate,
          });
        }
      } catch (err) {
        console.error(`Error fetching RSS for ${term}:`, err);
      }
    }

    // 2. Mock specific high-value leads (to ensure demo has good data)
    // Simulating "Government Tender RSS" which might be behind auth or complex
    leadsToAdd.push({
      companyName: "Bharat Heavy Electricals Ltd",
      location: "New Delhi",
      industry: "Power",
      signal: "Tender Notification",
      recommendedProducts: ["Furnace Oil", "LSHS"],
      confidence: 95,
      score: 98,
      status: "New",
      sourceLink: "https://tenders.gov.in/example",
      publicationDate: new Date(),
    });

    leadsToAdd.push({
      companyName: "Reliance Industries Jamnagar",
      location: "Jamnagar, Gujarat",
      industry: "Petrochemicals",
      signal: "Expansion News",
      recommendedProducts: ["Hexane", "Catalysts"],
      confidence: 85,
      score: 88,
      status: "Contacted",
      sourceLink: "https://news.google.com/example",
      publicationDate: new Date(Date.now() - 86400000 * 2),
    });

    // Save to DB
    let count = 0;
    for (const lead of leadsToAdd) {
      // Simple duplicate check could be here (e.g. by link)
      // For now, just insert
      await storage.createLead(lead);
      count++;
    }
    
    return { count, message: `Processed ${leadsToAdd.length} signals, added ${count} leads.` };
  }
}

export const leadAgent = new LeadAgent();
