
import { db } from "./db";
import { 
  leads, officers, contractors, tasks,
  type Lead, type InsertLead, type UpdateLeadRequest,
  type Officer, type InsertOfficer,
  type Contractor, type InsertContractor,
  type Task, type InsertTask, type UpdateTaskRequest
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Leads
  getLeads(status?: string, minScore?: number): Promise<Lead[]>;
  getLead(id: number): Promise<Lead | undefined>;
  createLead(lead: InsertLead): Promise<Lead>;
  updateLead(id: number, lead: UpdateLeadRequest): Promise<Lead>;
  
  // Officers
  getOfficers(): Promise<Officer[]>;
  createOfficer(officer: InsertOfficer): Promise<Officer>;
  
  // Contractors
  getContractors(): Promise<Contractor[]>;
  createContractor(contractor: InsertContractor): Promise<Contractor>;
  
  // Tasks
  getTasks(): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: UpdateTaskRequest): Promise<Task>;
}

export class DatabaseStorage implements IStorage {
  // Leads
  async getLeads(status?: string, minScore?: number): Promise<Lead[]> {
    let query = db.select().from(leads).orderBy(desc(leads.score));
    
    // Simple in-memory filtering for now if complex, or build query
    // Drizzle query builder:
    // if (status) query.where(eq(leads.status, status));
    // Implementation note: handling optional filters in fluent syntax can be verbose, 
    // retrieving all and filtering in memory for small datasets is acceptable, 
    // but proper where clauses are better.
    
    const results = await query;
    return results.filter(l => {
      if (status && l.status !== status) return false;
      if (minScore !== undefined && (l.score || 0) < minScore) return false;
      return true;
    });
  }

  async getLead(id: number): Promise<Lead | undefined> {
    const [lead] = await db.select().from(leads).where(eq(leads.id, id));
    return lead;
  }

  async createLead(lead: InsertLead): Promise<Lead> {
    const [newLead] = await db.insert(leads).values(lead).returning();
    return newLead;
  }

  async updateLead(id: number, updates: UpdateLeadRequest): Promise<Lead> {
    const [updated] = await db.update(leads)
      .set(updates)
      .where(eq(leads.id, id))
      .returning();
    return updated;
  }

  // Officers
  async getOfficers(): Promise<Officer[]> {
    return await db.select().from(officers);
  }

  async createOfficer(officer: InsertOfficer): Promise<Officer> {
    const [newOfficer] = await db.insert(officers).values(officer).returning();
    return newOfficer;
  }

  // Contractors
  async getContractors(): Promise<Contractor[]> {
    return await db.select().from(contractors);
  }

  async createContractor(contractor: InsertContractor): Promise<Contractor> {
    const [newContractor] = await db.insert(contractors).values(contractor).returning();
    return newContractor;
  }

  // Tasks
  async getTasks(): Promise<Task[]> {
    return await db.select().from(tasks).orderBy(desc(tasks.createdAt));
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db.insert(tasks).values(task).returning();
    return newTask;
  }

  async updateTask(id: number, updates: UpdateTaskRequest): Promise<Task> {
    const [updated] = await db.update(tasks)
      .set(updates)
      .where(eq(tasks.id, id))
      .returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
